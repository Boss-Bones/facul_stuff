import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class ex3 {
    public static void main(String[] args) {
        String str = "Olá mundo!! Olá programadores?!";
        String[] ls_str = str.toLowerCase().split("[\\p{Punct}\\s]+");

        Map<String, Integer> contando = new HashMap<>();
        for(String item : ls_str) {
            contando.merge(item, 1, Integer::sum);
        }

        System.out.println(contando);

        Map<String, Integer> contando_alf = new TreeMap<>();
        for(String item : ls_str) {
            contando_alf.merge(item, 1, Integer::sum);
        }

        System.out.println("\n" + contando_alf);

        List<Map.Entry<String, Integer>> ls_entradas = new ArrayList<>(contando.entrySet());
        ls_entradas.sort(Map.Entry.<String, Integer>comparingByValue().reversed().thenComparing(Map.Entry.comparingByKey()));

        System.out.println();
        for(int i = 0; i < 5 && i < ls_entradas.size(); i++) {
            System.out.println(ls_entradas.get(i).getKey() + ": " + ls_entradas.get(i).getValue());
        }

        Set<String> unicas = new TreeSet<>();
        for(String item : contando_alf.keySet()) {
            if(contando_alf.get(item) == 1) {
                unicas.add(item);
            }
        }

        System.out.println("\n" + unicas);

        Map<Integer, List<String>> por_tamanho = new TreeMap<>();
        for(String item : contando_alf.keySet()) {
            por_tamanho.computeIfAbsent(item.length(), k -> new ArrayList<>()).add(item);
        }

        System.out.println("\n" + por_tamanho);
    }
}