import java.util.Scanner;
import java.util.PriorityQueue;
import java.util.Comparator;
import java.util.Deque;
import java.util.ArrayDeque;

public class ex4 {
    enum Tipo { PRIORITARIO, COMUM }

    record Senha(int numero, String nome, Tipo tipo) {}

    static String formatar(Senha s) {
        return "Senha " + s.numero() + " - " + s.nome() + " (" + s.tipo() + ")";
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PriorityQueue<Senha> fila = new PriorityQueue<>(Comparator.comparing(Senha::tipo).thenComparingInt(Senha::numero));
        Deque<Senha> historico = new ArrayDeque<>();
        int contador = 1;

        while(true) {
            System.out.print("> ");
            String[] ls_cmd = sc.nextLine().trim().split("\\s+");
            String cmd = ls_cmd[0].toLowerCase();

            if(cmd.equals("novo")) {
                if(ls_cmd.length < 3) {
                    System.out.println("Uso: novo <nome> <tipo>");
                    continue;
                }

                String str_tipo = ls_cmd[ls_cmd.length - 1].toUpperCase();
                if(!str_tipo.equals("PRIORITARIO") && !str_tipo.equals("COMUM")) {
                    System.out.println("Tipo inválido. Use PRIORITARIO ou COMUM.");
                    continue;
                }

                String nome = "";
                for(int i = 1; i < ls_cmd.length - 1; i++) {
                    nome += (i > 1 ? " " : "") + ls_cmd[i];
                }

                Senha nova = new Senha(contador++, nome, Tipo.valueOf(str_tipo));
                fila.add(nova);
                System.out.println("Gerada: " + formatar(nova));
            }
            else if(cmd.equals("chamar")) {
                if(fila.isEmpty()) {
                    System.out.println("Fila vazia, nenhuma senha para chamar.");
                    continue;
                }

                Senha chamada = fila.poll();
                historico.push(chamada);
                System.out.println("Chamando: " + formatar(chamada));
            }
            else if(cmd.equals("desfazer")) {
                if(historico.isEmpty()) {
                    System.out.println("Histórico vazio, nada para desfazer.");
                    continue;
                }

                Senha devolvida = historico.pop();
                fila.add(devolvida);
                System.out.println("Devolvida à fila: " + formatar(devolvida));
            }
            else if(cmd.equals("listar")) {
                if(fila.isEmpty()) {
                    System.out.println("Fila vazia.");
                    continue;
                }

                PriorityQueue<Senha> copia = new PriorityQueue<>(fila);
                while(!copia.isEmpty()) {
                    System.out.println(formatar(copia.poll()));
                }
            }
            else if(cmd.equals("sair")) {
                System.out.println("Encerrando.");
                break;
            }
            else {
                System.out.println("Comando inválido. Use: novo, chamar, desfazer, listar ou sair.");
            }
        }

        sc.close();
    }
}