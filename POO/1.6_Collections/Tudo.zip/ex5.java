import java.util.Map;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Queue;
import java.util.ArrayDeque;
import java.util.Optional;
import java.util.Comparator;

public class ex5 {
    record Livro(String isbn, String titulo, String autor, int ano) {}

    static String formatar(Livro l) {
        return l.titulo() + " (" + l.ano() + ") - " + l.autor() + " [" + l.isbn() + "]";
    }

    static class Biblioteca {
        private Map<String, Livro> por_isbn = new HashMap<>();
        private Map<String, TreeSet<Livro>> por_autor = new HashMap<>();
        private Map<String, String> emprestimos = new HashMap<>();
        private Map<String, Queue<String>> fila_espera = new HashMap<>();
        private Map<String, Livro> cache = new LinkedHashMap<>(16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, Livro> mais_antigo) {
                return size() > 5;
            }
        };

        public void adicionar(Livro livro) {
            if(por_isbn.containsKey(livro.isbn())) {
                System.out.println("ISBN " + livro.isbn() + " já cadastrado, livro rejeitado: " + livro.titulo());
                return;
            }

            por_isbn.put(livro.isbn(), livro);
            por_autor.computeIfAbsent(livro.autor(), k -> new TreeSet<>(Comparator.comparingInt(Livro::ano).thenComparing(Livro::titulo))).add(livro);
            System.out.println("Adicionado: " + formatar(livro));
        }

        public Optional<Livro> buscarPorIsbn(String isbn) {
            if(cache.containsKey(isbn)) {
                return Optional.of(cache.get(isbn));
            }

            Livro livro = por_isbn.get(isbn);
            if(livro != null) {
                cache.put(isbn, livro);
            }

            return Optional.ofNullable(livro);
        }

        public List<String> isbnsNoCache() {
            return List.copyOf(cache.keySet());
        }

        public List<Livro> livrosDoAutor(String autor) {
            TreeSet<Livro> livros = por_autor.get(autor);
            if(livros == null) {
                return List.of();
            }

            return List.copyOf(livros);
        }

        public void emprestar(String isbn, String usuario) {
            if(!por_isbn.containsKey(isbn)) {
                System.out.println("ISBN " + isbn + " não existe.");
                return;
            }

            String titulo = por_isbn.get(isbn).titulo();

            if(!emprestimos.containsKey(isbn)) {
                emprestimos.put(isbn, usuario);
                System.out.println(titulo + " emprestado para " + usuario + ".");
            }
            else {
                fila_espera.computeIfAbsent(isbn, k -> new ArrayDeque<>()).add(usuario);
                System.out.println(titulo + " já está com " + emprestimos.get(isbn) + ", " + usuario + " entrou na fila de espera.");
            }
        }

        public void devolver(String isbn) {
            if(!por_isbn.containsKey(isbn)) {
                System.out.println("ISBN " + isbn + " não existe.");
                return;
            }

            String titulo = por_isbn.get(isbn).titulo();

            if(!emprestimos.containsKey(isbn)) {
                System.out.println(titulo + " não está emprestado.");
                return;
            }

            String usuario = emprestimos.remove(isbn);
            System.out.println(usuario + " devolveu " + titulo + ".");

            Queue<String> fila = fila_espera.get(isbn);
            if(fila != null && !fila.isEmpty()) {
                String proximo = fila.poll();
                emprestimos.put(isbn, proximo);
                System.out.println(titulo + " emprestado automaticamente para " + proximo + ".");
            }
        }

        public void relatorio() {
            List<Map.Entry<String, TreeSet<Livro>>> ls_autores = new ArrayList<>(por_autor.entrySet());
            ls_autores.sort((a, b) -> {
                int cmp = Integer.compare(b.getValue().size(), a.getValue().size());
                return cmp != 0 ? cmp : a.getKey().compareTo(b.getKey());
            });

            for(Map.Entry<String, TreeSet<Livro>> e : ls_autores) {
                System.out.println(e.getKey() + " (" + e.getValue().size() + " livros)");
                for(Livro l : e.getValue()) {
                    System.out.println("   " + l.ano() + " - " + l.titulo() + " [" + l.isbn() + "]");
                }
            }
        }
    }

    public static void main(String[] args) {
        Biblioteca bib = new Biblioteca();

        System.out.println("--- adicionar ---");
        bib.adicionar(new Livro("001", "Dom Casmurro", "Machado de Assis", 1899));
        bib.adicionar(new Livro("002", "Memórias Póstumas de Brás Cubas", "Machado de Assis", 1881));
        bib.adicionar(new Livro("003", "Quincas Borba", "Machado de Assis", 1891));
        bib.adicionar(new Livro("004", "A Hora da Estrela", "Clarice Lispector", 1977));
        bib.adicionar(new Livro("005", "Perto do Coração Selvagem", "Clarice Lispector", 1943));
        bib.adicionar(new Livro("006", "Capitães da Areia", "Jorge Amado", 1937));
        bib.adicionar(new Livro("007", "Gabriela, Cravo e Canela", "Jorge Amado", 1958));
        bib.adicionar(new Livro("008", "Vidas Secas", "Graciliano Ramos", 1938));
        bib.adicionar(new Livro("001", "Livro Repetido", "Fulano", 2000));

        System.out.println("\n--- buscarPorIsbn ---");
        bib.buscarPorIsbn("004").ifPresentOrElse(l -> System.out.println("Encontrado: " + formatar(l)), () -> System.out.println("Não encontrado."));
        bib.buscarPorIsbn("999").ifPresentOrElse(l -> System.out.println("Encontrado: " + formatar(l)), () -> System.out.println("ISBN 999 não encontrado."));

        System.out.println("\n--- livrosDoAutor ---");
        List<Livro> ls_machado = bib.livrosDoAutor("Machado de Assis");
        for(Livro l : ls_machado) {
            System.out.println(formatar(l));
        }
        System.out.println("Livros de autor inexistente: " + bib.livrosDoAutor("Ninguém"));

        try {
            ls_machado.add(new Livro("010", "Intruso", "Machado de Assis", 2020));
        }
        catch(UnsupportedOperationException e) {
            System.out.println("Lista imutável: não foi possível alterar.");
        }

        System.out.println("\n--- emprestar e fila de espera ---");
        bib.emprestar("001", "Ana");
        bib.emprestar("001", "Bruno");
        bib.emprestar("001", "Carla");
        bib.emprestar("999", "Davi");

        System.out.println("\n--- devolver ---");
        bib.devolver("001");
        bib.devolver("001");
        bib.devolver("001");
        bib.devolver("001");
        bib.devolver("999");

        System.out.println("\n--- relatorio ---");
        bib.relatorio();

        System.out.println("\n--- cache LRU ---");
        bib.buscarPorIsbn("001");
        bib.buscarPorIsbn("002");
        bib.buscarPorIsbn("003");
        bib.buscarPorIsbn("005");
        bib.buscarPorIsbn("006");
        System.out.println("Cache: " + bib.isbnsNoCache());
        bib.buscarPorIsbn("002");
        bib.buscarPorIsbn("008");
        System.out.println("Cache: " + bib.isbnsNoCache());
    }
}