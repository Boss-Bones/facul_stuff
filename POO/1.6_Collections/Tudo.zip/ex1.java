import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;

public class ex1 {
    List<String> ls_compras = new ArrayList<String>();
    Scanner leitura = new Scanner(System.in);

    void listar() {
        for(int i = 0; i < ls_compras.size(); i++) {
            System.out.println((i+1) + ":" + ls_compras.get(i));
        }
    }

    void remover_por_nome(String item) {
        ls_compras.remove(item);
    }

    void remover_por_indice(int item) {
        ls_compras.remove(item);
    }

    public void main(String[] args) {
        ls_compras.add("Arroz");
        ls_compras.add("Feijão");
        ls_compras.add("Frango");
        ls_compras.add("Abóbora");
        ls_compras.add("Frango");
        ls_compras.add("Picanha");
        ls_compras.add("Leite");

        listar();

        System.out.print("\nFale um nome de um item: ");
        String item_str = leitura.nextLine(); remover_por_nome(item_str);
        System.out.println("Pronto, removi esse item :)");
        System.out.println("");

        listar();

        System.out.print("\nFale um indice de um item: ");
        int item_int = leitura.nextInt(); remover_por_indice(item_int-1);
        System.out.println("Pronto, removi esse item :)");
        System.out.println("");

        listar();

        System.out.println("");
        if(ls_compras.contains("Leite")){
            System.out.println("Tem leite na lista, só por informacão");
        } else {
            System.out.println("Não tem leite na lista, só por informacão");
        }

        System.out.println("\nLista ordenada em ordem alfabetica:");
        ls_compras.sort(null);
        listar();

        System.out.println("\nLista ordenada em ordem inversa a anterior:");
        ls_compras.sort(Comparator.reverseOrder());
        listar();

        System.out.println("\nO item repetido, que no caso é o frango, aparece " + Collections.frequency(ls_compras, "Frango") + " vezes!");
    }
}
