import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.LinkedHashSet;

public class ex2 {
    List<String> festaA = List.of("ana@ex.com", "bia@ex.com", "caio@ex.com", "ana@ex.com", "davi@ex.com");
    List<String> festaB = List.of("caio@ex.com", "eva@ex.com", "davi@ex.com", "eva@ex.com", "fabio@ex.com");

    public void main(String[] args) {
        System.out.println("Estão na festa A:");
        for(String item : festaA) {
            System.out.println(item);
        }

        System.out.println("\nTodos os convidados das duas festas:");
        Set<String> uniao = new LinkedHashSet<>(festaA); uniao.addAll(festaB);
        List<String> festaAB = new ArrayList<String>(uniao); festaAB.sort(null);
        for(String item : festaAB) {
            System.out.println(item);
        }

        System.out.println("\nTodos os convidados que estão nas duas festas:");
        Set<String> intersecao = new LinkedHashSet<>(festaA); intersecao.retainAll(festaB);
        List<String> festaAeB = new ArrayList<String>(intersecao);
        for(String item : festaAeB) {
            System.out.println(item);
        }

        System.out.println("\nEstão apenas na festa A:");
        Set<String> diferenca = new LinkedHashSet<>(festaA); uniao.removeAll(festaB);
        List<String> festaAapenas = new ArrayList<String>(diferenca);
        for(String item : festaAapenas) {
            System.out.println(item);
        }

        System.out.println("\nExistem " + festaAB.size() + " pessoas distintas no local");
    }
}
